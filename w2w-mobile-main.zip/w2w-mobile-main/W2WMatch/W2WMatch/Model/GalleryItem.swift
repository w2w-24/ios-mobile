//
//  GalleryItem.swift
//  W2WMatch
//
//  Created by Игорь Крысин on 19.06.2024.
//

import Foundation

class GalleryItem: ObservableObject {
    var PhotoData: Data?
}

