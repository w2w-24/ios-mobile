//
//  AlertServise.swift
//  W2WMatch
//
//  Created by Floron on 07.06.2024.
//

import Foundation

/*
class AlertService {
    private init (){}
    
    static let shared = AlertService()

    func showAllert (controller: UIViewController, error: TextErrors) {
        let alert = UIAlertController(title: "Ошибка", message: error.rawValue, preferredStyle: .alert)
        alert.addAction(.init(title: "OK", style: .default))
        controller.present(alert, animated: true)
    }
}
*/
