//
//  UserModel.swift
//  W2WMatch
//
//  Created by Floron on 08.06.2024.
//

import Foundation


class UserModel {
    var email: String = ""
    var password: String = ""
    var phone: String = ""
    var refreshToken = ""
    var accessToken = ""
}
