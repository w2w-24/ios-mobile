//
//  W2WMatchApp.swift
//  W2WMatch
//
//  Created by Floron on 02.06.2024.
//

import SwiftUI

@main
struct W2WMatchApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
