//
//  PhotoModel.swift
//  W2WMatch
//
//  Created by Игорь Крысин on 21.06.2024.
//

import Foundation

struct PhotoModel {
//    static func tapToBtn(photoData: Data) {
//        if let photoData, let uiImage = UIImage(data: photoData) {
//            let img = uiImage
//            let base64 = img.base64
//            let rebornImg = base64?.imageFromBase64
//            guard let rebornImg = rebornImg else { return }
//            
//            self.text = img.jpegData(compressionQuality: 1)?.base64EncodedString() ?? ""
//            
//            print("Base 64 string:", rebornImg)
//            print(text)
//        }
//        
//    }
}
