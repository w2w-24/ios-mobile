//
//  Match.swift
//  W2WMatch
//
//  Created by Floron on 16.06.2024.
//

import SwiftUI

struct MatchView: View {
    var body: some View {
        Text("It's Match View")
    }
}

#Preview {
    MatchView()
}
